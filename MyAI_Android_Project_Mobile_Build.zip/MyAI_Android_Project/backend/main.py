import os
import sqlite3
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

APP_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("CHAT_DB_PATH", APP_DIR / "chats.db"))
API_KEY = os.getenv("GEMINI_API_KEY")
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

app = FastAPI(title="My AI API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict this to your app's web origin if applicable.
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["*"],
)

def db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    return con

class ChatRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=100)
    message: str = Field(min_length=1, max_length=12000)

class ChatResponse(BaseModel):
    reply: str

@app.get("/")
def health():
    return {"status": "ok", "app": "My AI"}

@app.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    if not API_KEY:
        raise HTTPException(status_code=503, detail="Server Gemini API key is not configured.")
    try:
        con = db()
        rows = con.execute(
            "SELECT role, content FROM messages WHERE session_id=? ORDER BY id DESC LIMIT 20",
            (payload.session_id,)
        ).fetchall()
        con.close()
        rows.reverse()

        history = [
            types.Content(
                role=role,
                parts=[types.Part.from_text(text=content)]
            )
            for role, content in rows
        ]

        client = genai.Client(api_key=API_KEY)
        chat_session = client.chats.create(
            model=MODEL,
            history=history,
            config=types.GenerateContentConfig(
                system_instruction=(
                    "You are My AI, a helpful and honest assistant. "
                    "Reply in the language used by the user. "
                    "If you are unsure, say so clearly."
                )
            ),
        )
        result = chat_session.send_message(payload.message)
        answer = result.text or "দুঃখিত, কোনো উত্তর পাওয়া যায়নি।"

        con = db()
        con.executemany(
            "INSERT INTO messages(session_id, role, content) VALUES (?, ?, ?)",
            [
                (payload.session_id, "user", payload.message),
                (payload.session_id, "model", answer),
            ],
        )
        con.commit()
        con.close()
        return ChatResponse(reply=answer)
    except HTTPException:
        raise
    except Exception as exc:
        # Do not expose API keys or internal stack traces to the app.
        raise HTTPException(status_code=502, detail=f"AI request failed: {type(exc).__name__}")

@app.get("/history/{session_id}")
def get_history(session_id: str):
    con = db()
    rows = con.execute(
        "SELECT role, content, created_at FROM messages WHERE session_id=? ORDER BY id",
        (session_id,),
    ).fetchall()
    con.close()
    return {"messages": [
        {"role": role, "content": content, "created_at": created}
        for role, content, created in rows
    ]}

@app.delete("/history/{session_id}")
def clear_history(session_id: str):
    con = db()
    con.execute("DELETE FROM messages WHERE session_id=?", (session_id,))
    con.commit()
    con.close()
    return {"status": "deleted"}
