import threading
import uuid
import requests

from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import StringProperty, BooleanProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.metrics import dp

# IMPORTANT: Replace with your deployed backend's HTTPS URL.
API_URL = "https://YOUR-BACKEND-DOMAIN.example"

KV = """
<ChatBubble>:
    size_hint_y: None
    height: self.minimum_height
    padding: dp(12)
    canvas.before:
        Color:
            rgba: (0.16, 0.19, 0.25, 1) if self.sender == "My AI" else (0.20, 0.31, 0.50, 1)
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(14)]
    Label:
        text: ("[b]" + root.sender + "[/b]\\\\n" + root.message)
        markup: True
        color: 0.95, 0.96, 0.99, 1
        text_size: self.width, None
        size_hint_y: None
        height: self.texture_size[1]
        halign: "left"
        valign: "middle"

<Root>:
    orientation: "vertical"
    padding: dp(14)
    spacing: dp(10)

    BoxLayout:
        size_hint_y: None
        height: dp(48)
        Label:
            text: "My AI"
            bold: True
            font_size: "24sp"
            color: 0.55, 0.72, 1, 1
            halign: "left"
        Button:
            text: "New chat"
            size_hint_x: None
            width: dp(100)
            on_release: root.new_chat()

    ScrollView:
        id: scroll
        do_scroll_x: False
        BoxLayout:
            id: messages
            orientation: "vertical"
            size_hint_y: None
            height: self.minimum_height
            spacing: dp(10)
            padding: dp(2)

    Label:
        text: root.status
        size_hint_y: None
        height: dp(22)
        color: 0.65, 0.72, 0.82, 1
        font_size: "12sp"

    BoxLayout:
        size_hint_y: None
        height: dp(54)
        spacing: dp(8)
        TextInput:
            id: prompt
            hint_text: "Ask My AI anything..."
            multiline: False
            write_tab: False
            on_text_validate: root.send_message()
        Button:
            text: "Send"
            size_hint_x: None
            width: dp(76)
            disabled: root.busy
            on_release: root.send_message()
"""

class ChatBubble(BoxLayout):
    sender = StringProperty("")
    message = StringProperty("")

class Root(BoxLayout):
    status = StringProperty("Ready")
    busy = BooleanProperty(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.session_id = str(uuid.uuid4())
        Clock.schedule_once(lambda _dt: self.add_message(
            "My AI", "হ্যালো! আমি My AI। আমাকে যেকোনো প্রশ্ন করতে পারো।"
        ), 0)

    def add_message(self, sender, message):
        bubble = ChatBubble(sender=sender, message=message)
        self.ids.messages.add_widget(bubble)
        Clock.schedule_once(lambda _dt: setattr(
            self.ids.scroll, "scroll_y", 0
        ), 0.15)

    def send_message(self):
        if self.busy:
            return
        prompt = self.ids.prompt.text.strip()
        if not prompt:
            return
        self.ids.prompt.text = ""
        self.add_message("You", prompt)
        self.busy = True
        self.status = "My AI is thinking..."
        threading.Thread(
            target=self._request_reply, args=(prompt,), daemon=True
        ).start()

    def _request_reply(self, prompt):
        try:
            if "YOUR-BACKEND-DOMAIN" in API_URL:
                raise RuntimeError("Set your deployed backend HTTPS URL in android/main.py")
            response = requests.post(
                API_URL.rstrip("/") + "/chat",
                json={"session_id": self.session_id, "message": prompt},
                timeout=120,
            )
            response.raise_for_status()
            answer = response.json().get("reply", "No reply received.")
            Clock.schedule_once(lambda _dt: self._show_reply(answer), 0)
        except Exception as exc:
            message = str(exc)
            Clock.schedule_once(lambda _dt: self._show_error(message), 0)

    def _show_reply(self, answer):
        self.add_message("My AI", answer)
        self.busy = False
        self.status = "Ready"

    def _show_error(self, message):
        self.add_message("My AI", "Connection error: " + message)
        self.busy = False
        self.status = "Could not connect"

    def new_chat(self):
        self.session_id = str(uuid.uuid4())
        self.ids.messages.clear_widgets()
        self.add_message("My AI", "নতুন চ্যাট শুরু হয়েছে। কী জানতে চাও?")
        self.status = "Ready"

class MyAIApp(App):
    def build(self):
        self.title = "My AI"
        self.theme_cls = None
        from kivy.core.window import Window
        Window.clearcolor = (0.055, 0.07, 0.10, 1)
        Builder.load_string(KV)
        return Root()

if __name__ == "__main__":
    MyAIApp().run()
