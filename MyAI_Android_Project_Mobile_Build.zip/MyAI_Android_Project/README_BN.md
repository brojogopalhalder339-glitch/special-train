# My AI — Android starter project

এটি একটি Python/Kivy Android chat app এবং FastAPI + Gemini backend-এর starter project। এটি এখনই production-ready Gemini clone নয়; APK বানানোর আগে backend deploy ও API URL সেট করতে হবে।

## ১) Gemini API key
Google AI Studio থেকে API key নিন: https://aistudio.google.com/apikey

`backend/.env.example` কপি করে `.env` করুন এবং key বসান। `.env` কখনও GitHub বা APK-তে দেবেন না।

## ২) Backend চালান (লোকাল টেস্ট)
```bash
cd backend
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
export GEMINI_API_KEY="YOUR_KEY"
uvicorn main:app --host 0.0.0.0 --port 8000
```
Windows PowerShell:
```powershell
$env:GEMINI_API_KEY="YOUR_KEY"
uvicorn main:app --host 0.0.0.0 --port 8000
```
স্বাস্থ্য পরীক্ষা: `http://127.0.0.1:8000/`

## ৩) Backend অনলাইনে deploy করুন
একটি HTTPS-সমর্থিত Python hosting service-এ `backend/` deploy করুন। Environment variable হিসেবে `GEMINI_API_KEY` এবং চাইলে `GEMINI_MODEL=gemini-2.5-flash` সেট করুন। SQLite ফাইলের জন্য persistent disk/volume দরকার; ephemeral hosting হলে database মুছে যেতে পারে। Public deployment-এর আগে authentication, per-user authorization, rate limiting, request quotas এবং CORS policy যোগ করুন।

## ৪) Android URL সেট করুন
`android/main.py`-এর `API_URL`-এ deployed backend-এর HTTPS base URL দিন, যেমন `https://api.yourdomain.com`। `http://127.0.0.1` ফোনে কাজ করবে না।

## ৫) APK build
Ubuntu বা Windows WSL2-তে Buildozer চালান:
```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip python3-venv \
  autoconf libtool pkg-config zlib1g-dev libncurses-dev libffi-dev libssl-dev cmake
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip buildozer cython
cd android
buildozer android debug
```
প্রথম build-এ Android SDK/NDK ডাউনলোড হবে, তাই সময় ও ইন্টারনেট লাগবে। APK সাধারণত `android/bin/`-এ তৈরি হবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই starter version-এ text chat, new chat এবং server-side chat history আছে।
- Voice, image upload, PDF upload, login/signup, streaming, multi-device sync এখনো implement করা হয়নি।
- `session_id` একা নিরাপদ user authentication নয়। Production-এ account login ও server-side access control আবশ্যক।
- Gemini model availability/নাম Google AI Studio-তে আপনার account ও অঞ্চলে যাচাই করুন।
- API key শুধুমাত্র backend environment variable-এ রাখুন; APK-তে embed করবেন না।
